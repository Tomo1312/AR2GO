package com.example.ar2go;


public class Sculpture {

    public String name, description, author, imagePath, points, latitude, longitude;
}
